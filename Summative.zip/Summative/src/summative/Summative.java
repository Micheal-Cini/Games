package summative;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Robot;
import java.io.IOException;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;

@SuppressWarnings("serial")
public class Summative extends JFrame {

    public static void main(String[] args) {
        
         UIManager.put("OptionPane.background",new ColorUIResource(102, 0, 0));
         UIManager.put("Panel.background",new ColorUIResource(102, 0, 0));
         UIManager.put("OptionPane.messageForeground", Color.YELLOW);

        Summative cdframe = new Summative();
        ImageIcon icon = new ImageIcon("res//sword-icon-consist-from-lot-of-pixels-color-card-vector-21344106.png/");
        String[] options = {"I'm Ready!", "Do I have a choice?", "Rules", "About"};
        int x = JOptionPane.showOptionDialog(cdframe, "Welcome to The Adventure of Schlatt!             \n             Would you like to play?",
                "The Adventure of Schlatt!", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);
        boolean key = false;
        boolean life = false;
       
        if (x == 0) {
                JFrame fr = new JFrame();
                begining(key, fr, life);
            cdframe.repaint();
            cdframe.revalidate();
        }
        else if (x==1){
                JFrame fr = new JFrame();
                JOptionPane.showMessageDialog(fr, "Nope!");
                begining(key, fr, life);
            cdframe.repaint();
            cdframe.revalidate();
        }
        else if (x==2){
                JFrame fr = new JFrame();
                ImageIcon icon1 = new ImageIcon("res/Example Text.PNG");
                ImageIcon icon2 = new ImageIcon("res/Cant.PNG");
                ImageIcon icon3 = new ImageIcon("res/Fail.PNG");
                JOptionPane.showMessageDialog(fr,"A text box will open describing a scene or scenario.\nYou will enter an action to be performed.", "Rules", x, icon1);
                JOptionPane.showMessageDialog(fr,"Once the action is entered, it will either continue to the next part, or tell you \"You Cant _____\"", "Rules", x, icon2);
                JOptionPane.showMessageDialog(fr,"There are several puzzles that will have to be solved.\nFailing to solve puzzles will result in a fail.", "Rules", x, icon3);
                JOptionPane.showMessageDialog(fr,"If one word doesn't work, try another word or phrase with the same meaning.\nMost words are directions but some will use words like enter, use, take, or put.\nGood Luck!", "Rules", x);
                main(options);
        }
        else if (x==3){
        	   JFrame fr = new JFrame();
               JOptionPane.showMessageDialog(fr,"                         The Game Adventure of Schlatt is a text based adventure game that allows the user to control the story.\n"
               		+ 							"                                     It uses a series of arrays, if statements, and do-while loops to perform tasks in the game.\n"
               		+ 							"The game also uses several premade classes like the random class and the dialog boxes to create the game interface and puzzles.\n"
               		+ 							"                                         The game is inspired off of the online game \"Zork\" which is also a text based game.\n"
               		+ 							"                                          There are many hidden \"Easter Eggs\" that can be found around the world of schlatt\n"
               		+ 							"     While makeing the adventure of schlatt, I wanted to include many fun puzzles but also include some challenges along the way.\n"
               		+ 							"                                            I plan to continue updating the game by adding more puzzles, options, and endings.");
               main(options);
        }
    }

        private static void begining(boolean key, JFrame fr2, boolean life){
                String answer = JOptionPane.showInputDialog("You find yourself in a school.\nThere's nothing around you except for a locker with a dent, and a hallway that leads North");
                if (answer.equalsIgnoreCase("go North")|answer.equalsIgnoreCase("North")|answer.equalsIgnoreCase("N")) {
                        NorthHall(key, fr2, life);
                }
                else if(answer.equalsIgnoreCase("open locker")|answer.equalsIgnoreCase("go to locker")) {
                        openLocker(key, fr2, life);
                        }
                else if(answer.equalsIgnoreCase("fail")) {
                        northRoom(fr2, life);
                }
                else if (answer.equalsIgnoreCase("go south")|answer.equalsIgnoreCase("south")|answer.equalsIgnoreCase("s")) {
                        if (!life) {
                        JOptionPane.showMessageDialog(fr2, "You walk south and the floor drops beneth you");
                        JOptionPane.showMessageDialog(fr2, "You land in a dark room with no exits");
                        fail(fr2, life);
                        }
                        
                        else if(life) {
                                JOptionPane.showMessageDialog(fr2, "You cant "+answer);
                                begining(key, fr2, life);
                        }
                }
                else if (answer.equalsIgnoreCase("go East")|answer.equalsIgnoreCase("east")|answer.equalsIgnoreCase("e")) {
                        JOptionPane.showMessageDialog(fr2, "Shutdown feature currently disabled");
                        //shutdown();
                }
                else {
                        JFrame fr = new JFrame();
                        JOptionPane.showMessageDialog(fr, "You can't "+answer);
                        begining(key, fr2, life);
                }
                
                
                
        }

        private static void shutdown() {
                try {
                        Robot r = new Robot();
                } catch (AWTException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
                Robot bot;
                try {
                        bot = new Robot();
                } catch (AWTException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
                Runtime runTime = Runtime.getRuntime();
                try {
                        Process process = runTime.exec("C:\\Windows\\System32\\shutdown.exe -s");
                } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
        }
                
                
                
        
                

        private static void openLocker(boolean key, JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("You open the locker and find a key with the number 116 on it");
                if(answer.equalsIgnoreCase("take key")|answer.equalsIgnoreCase("pick up key")){
                        JOptionPane.showMessageDialog(fr2, "Key Taken");
                        key = true;
                        begining(key, fr2, life);
                }
                else if (answer.equalsIgnoreCase("go North")|answer.equalsIgnoreCase("North")|answer.equalsIgnoreCase("N")) {
                        NorthHall(key, fr2, life);
                }
                else if(answer.equalsIgnoreCase("enter locker")|answer.equalsIgnoreCase("go in locker")) {
                        if (life) {
                                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        }
                        else {
                        locker(fr2, life);
                        }
                }
                else 
                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                openLocker(key, fr2, life);
                
        }

        private static void locker(JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("You uncomfortably enter the locker.\nAs you close the door behind you, it locks shut and a light with a siren turns on\nA button comes out of the wall");
                if(answer.equalsIgnoreCase("push button")|answer.equalsIgnoreCase("press button")|answer.equalsIgnoreCase("hit button")) {
                        String answer1 = JOptionPane.showInputDialog("As soon as you press the button, the floor drops beneth you.\nYou land in a room with the number 6495 painted all over the walls\nYou see a pathway leading North, and a random outhouse under a small overhang.");
                        if(answer1.equalsIgnoreCase("open outhouse")|answer1.equalsIgnoreCase("go to outhouse")) {
                                JOptionPane.showMessageDialog(fr2, "As you walk towards the outhouse, the door bursts open and a green ogre wearing a brown vest bursts out\nYou stumble back in fear but he smiles and hands you a card\nYou grab the card");
                                life=true;
                                begining(life, fr2, life);
                        }
                        else if (answer1.equalsIgnoreCase("go North")|answer1.equalsIgnoreCase("North")|answer1.equalsIgnoreCase("N")) {
                                northTunnel(fr2);
                        }
                        else {
                                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                                locker(fr2, life);
                        }
                }
                        
                
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        locker(fr2, life);
                }
        }

        private static void northTunnel(JFrame fr2) {
                String answer = JOptionPane.showInputDialog("You enter a water service room with a hole in the floor and a door leading east");
                if (answer.equalsIgnoreCase("go East")|answer.equalsIgnoreCase("east")|answer.equalsIgnoreCase("e")) {
                        eastTunnel(fr2);
                }
                else if (answer.equalsIgnoreCase("enter hole")|answer.equalsIgnoreCase("go in hole")){
                	JOptionPane.showMessageDialog(fr2, "You look in the hole and see very fast flowing water.\nYou decide it's best to not enter the hole.");
                }
                else{
                	JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                	northTunnel(fr2);
                }
        }

        private static void eastTunnel(JFrame fr2) {
        	 String answer = JOptionPane.showInputDialog("You walk east into a long tunnel");
                
        }

        private static void NorthHall(boolean key, JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("You see several classrooms, one of them has a faint light on to the west.");
                
                if(answer.equalsIgnoreCase("enter classroom")|answer.equalsIgnoreCase("go to classroom")|answer.equalsIgnoreCase("go in classroom")|answer.equalsIgnoreCase("go west")|answer.equalsIgnoreCase("west")|answer.equalsIgnoreCase("w")) {
                        
                        if (!key) {
                                JOptionPane.showMessageDialog(fr2, "You need a Key");
                                NorthHall(key, fr2, life);
                        }
                        else if (key=true) {
                                classroom(key, fr2, life);
                        }
                }
                        
                else if (answer.equalsIgnoreCase("go south")|answer.equalsIgnoreCase("south")|answer.equalsIgnoreCase("s")){
                        begining(key, fr2, life);
                
                }
                else { 
                                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                                NorthHall(key, fr2, life);
                }
        
        }

        private static void classroom(boolean key, JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("The classroom has many computers around the walls.\nOne computer is turned on in the middle of the room.");
                if (answer.equalsIgnoreCase("leave classroom")) {
                        NorthHall(key, fr2, life);
                }
                else if (answer.equalsIgnoreCase("go to computer")|answer.equalsIgnoreCase("walk to computer")|answer.equalsIgnoreCase("Use computer")) {
                        computer(key, fr2, life);
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        classroom(key, fr2, life);
                }
        }

        private static void computer(boolean key, JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("The computer has a button on the screen saying \"test your intelligence\"");
                if (answer.equalsIgnoreCase("press button")|answer.equalsIgnoreCase("click button")|answer.equalsIgnoreCase("hit button")) {
                        button(fr2, life);
                }
                else if (answer.equalsIgnoreCase("leave computer")) {
                        classroom(key, fr2, life);
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        computer(key, fr2, life);
                }
                
        }

        @SuppressWarnings("unlikely-arg-type")
		private static void button(JFrame fr2, boolean life) {
                JOptionPane.showMessageDialog(fr2, "Several questions appear on the screen");
                Random rnd = new Random();
                int rnd1= rnd.nextInt(11);
                int rnd2= rnd.nextInt(11);
                int answer = Integer.parseInt(JOptionPane.showInputDialog(rnd1+"+"+rnd2));
                if (answer==rnd1+rnd2) {
                        String answer1 = JOptionPane.showInputDialog("Capital of Canada");
                        if(answer1.equalsIgnoreCase("Ottawa")) {
                                String answer2 = JOptionPane.showInputDialog("Shayans Last Name");
                                if (answer2.equalsIgnoreCase("Vafapisheh")) {
                                        String answer3 = JOptionPane.showInputDialog("Best Computer Science Teacher");
                                        if (answer3.equalsIgnoreCase("Mrs. D'angelo")|answer3.equalsIgnoreCase("Mrs. D")) {
                                                JOptionPane.showMessageDialog(fr2, "You have passed the test!");
                                                pass(fr2, life);
                                        }
                                        else {
                                                fail(fr2, life);
                                        }
                                }
                                else {
                                        fail(fr2, life);
                                }
                        }
                        else {
                                fail(fr2, life);
                        }
                }
                else if (answer == 6495) {
                        String answer4 = JOptionPane.showInputDialog("Nuclear Detonation initiated\n10Seconds until detonation");
                        if (answer4.equalsIgnoreCase("break computer")|(answer4.equalsIgnoreCase("break computer"))){
                                JOptionPane.showMessageDialog(fr2, "You smash the computer to bits, aborting the detonation");
                                pass(fr2, life);
                        }
                        else {
                        JOptionPane.showMessageDialog(fr2, "Detonation Activated");
                        end();
                        }
                        
                }
                        
                else {
                        fail(fr2, life);
                }
                
        }

        private static void pass(JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("You hear a loud noise behind you\nA secret door has opened where the projector used to be\nThere is a light illuminating from a desk drawer");
                if (answer.equalsIgnoreCase("open drawer")|answer.equalsIgnoreCase("open the drawer")|answer.equalsIgnoreCase("open the desk drawer")) {
                	String answer1;
					do {
                	answer1 = JOptionPane.showInputDialog("There is a flashlight");
                        if (answer1.equalsIgnoreCase("take flashlight")) {
                                JOptionPane.showMessageDialog(fr2, "Flashlight Taken");
                                passFlashlight(fr2, life);
                        }
                        else {
                                JOptionPane.showMessageDialog(fr2, "You can't "+answer1);
                        }
                        }while(!answer1.equalsIgnoreCase("take flashlight"));
                
                }
                else if(answer.equalsIgnoreCase("enter door")) {
                         String[] options = {"Yes!", "No!"};
                        int x = JOptionPane.showOptionDialog(fr2, "Its pretty dark in there, are you sure you want to enter?",
                                "Confirm", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
                        if (x==0) {
                                if (!life) {
                                UIManager.put("OptionPane.background", Color.BLACK);
                                UIManager.put("Panel.background", Color.BLACK);
                                UIManager.put("OptionPane.messageForeground", Color.RED);
                                ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                                JOptionPane.showMessageDialog(null, "You walk through the door only to get lost in the darkness.\nAs you're panicing to find the exit, you slip and fall.\nNever to be seen again.", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                                main(null);
                        }
                                
                        else if(life) {
                                        UIManager.put("OptionPane.background", Color.PINK);
                                        UIManager.put("Panel.background", Color.PINK);
                                        UIManager.put("OptionPane.messageForeground", Color.RED);
                                        ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                                        JOptionPane.showMessageDialog(null, "The card that the ogre gave you was an extra life card, spareing you just this once", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                                        life=false;

                                 UIManager.put("OptionPane.background",new ColorUIResource(102, 0, 0));
                                 UIManager.put("Panel.background",new ColorUIResource(102, 0, 0));
                                 UIManager.put("OptionPane.messageForeground", Color.YELLOW);
                                        pass(fr2, life);
                                }

                }
                        else if(x==1) {
                                pass(fr2, life);
                        }
                }
                else{
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        pass(fr2, life);
                }
        }

        private static void passFlashlight(JFrame fr2, boolean life) {
                String answer = JOptionPane.showInputDialog("You hear a loud noise behind you\nA secret door has opened where the projector used to be\n");
                if(answer.equalsIgnoreCase("enter door")) {
                        door(fr2, life, life, life);
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        passFlashlight(fr2, life);
                }
                
        }
        

        private static void door(JFrame fr2, boolean battery, boolean lights, boolean life) {
                String answer = JOptionPane.showInputDialog("You enter the dark room as the door slams shut behind you.\nYou reach the bottom of a set of stairs leading to what seems to be three different directions\nNorth, West, and East");
                System.out.println(battery);
                if (answer.equalsIgnoreCase("go North")|answer.equalsIgnoreCase("North")|answer.equalsIgnoreCase("N")) {
                        northRoom(fr2, battery);
                }
                else if (answer.equalsIgnoreCase("go East")|answer.equalsIgnoreCase("east")|answer.equalsIgnoreCase("e")) {
                        System.out.println(battery);
                        eastRoom(fr2, battery, lights);
                }
                else if (answer.equalsIgnoreCase("go West")|answer.equalsIgnoreCase("west")|answer.equalsIgnoreCase("w")){
                        westRoom(fr2, battery, lights, life);
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        door(fr2, battery, lights, life);
                }
                
        }

        private static void westRoom(JFrame fr2, boolean battery, boolean lights, boolean life) {
                String answer = JOptionPane.showInputDialog("You enter a small room with a foul odour.\nThere's a small hole in the floor just big enough for a human.\nYour flashlight flickers when pointed at it.");
                if (answer.equalsIgnoreCase("go East")|answer.equalsIgnoreCase("east")|answer.equalsIgnoreCase("e")) {
                        door(fr2, battery, lights, life);
                }
                else if (answer.equalsIgnoreCase("enter hole")) {
                        if(!lights) {
                                holeDeath(life, fr2);
                        }
                        else if (lights) {
                                hole(fr2, life);
                        }
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        westRoom(fr2, battery, lights, life);
                }
        }

        private static void holeDeath(boolean life, JFrame fr2) {
                if(!life) {
                UIManager.put("OptionPane.background", Color.BLACK);
                UIManager.put("Panel.background", Color.BLACK);
                UIManager.put("OptionPane.messageForeground", Color.RED);
                ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                JOptionPane.showMessageDialog(null, "You hear a sound behind you, but before you can look, you feel a sharp pain in your legs and you are dragged to your doom.", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                main(null);
                }
                else if(life) {
                        UIManager.put("OptionPane.background", Color.PINK);
                        UIManager.put("Panel.background", Color.PINK);
                        UIManager.put("OptionPane.messageForeground", Color.RED);
                        ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                        JOptionPane.showMessageDialog(null, "The card that the ogre gave you was an extra life card, spareing you just this once", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                        life=false;

                 UIManager.put("OptionPane.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("Panel.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("OptionPane.messageForeground", Color.YELLOW);
                        westRoom(fr2, life, life, life);
                }
        }

        private static void hole(JFrame fr2, boolean life) {
                JOptionPane.showMessageDialog(fr2, "You enter a dark small crawl hole\nAs you crawl aimlessly for a few minutes your flashlight becomes dim.\nYou reach a small room with 4 flashing lights.");
                int i=0;
                while(i<3){
                	i++;
                String[] options = {"Red", "Yellow", "Green", "Blue"};
                Random rnd=new Random();
                int color1 = rnd.nextInt(4);
                int color2 = rnd.nextInt(4);
                int color3 = rnd.nextInt(4);
                int color4 = rnd.nextInt(4);
                
                JOptionPane.showMessageDialog(fr2, options[color1]+", "+options[color2]+", "+options[color3]+", "+options[color4]);
                
                int x = JOptionPane.showOptionDialog(fr2, " ",
                                " ", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[3]);
                if (x==color1) {
                        x = JOptionPane.showOptionDialog(fr2, " ",
                                        " ", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[3]);
                        if (x==color2) {
                                x = JOptionPane.showOptionDialog(fr2, " ",
                                                " ", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[3]);
                                if (x==color3) {
                                        x = JOptionPane.showOptionDialog(fr2, " ",
                                                        " ", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[3]);
                                        if (x==color4) {
                                                JOptionPane.showMessageDialog(fr2, "Correct");
                                                if(i==3){
                                                	lightPass(fr2);
                                                }
                                        }
                                        else {
                                        lightFail(fr2, life);
                                        }
                                }
                                else {
                                lightFail(fr2, life);
                                }
                        }
                        else {
                                lightFail(fr2, life);
                        }
                }
                else {
                        lightFail(fr2, life);
                }
                
                }
                       
        }

        private static void lightPass(JFrame fr2) {
                String answer = JOptionPane.showInputDialog("As you finish entering the final combination, all the lights turn green and the floor starts to lower.\nIt brings you into a cozy room, with money everywhere.\nThere's a bottle of Champagne on a table");
                if(answer.equalsIgnoreCase("drink Champagne")) {
                        JOptionPane.showMessageDialog(fr2, "You open the bottle of champange and take a drink. You lay down on a nearby couch and take a nap after a long day");
                        JOptionPane.showMessageDialog(fr2, "When you wake up, you're in your bed, in your house. You look around and wonder was it real?");
                        end();
                }
                else {
                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                lightPass(fr2);
                }
                
        }

        private static void end() {
                
                JOptionPane.showMessageDialog(null, "Thanks For Playing", " ", JOptionPane.INFORMATION_MESSAGE);
                main(null);
                
        }

        private static void lightFail(JFrame fr2, boolean life) {
                
                if (!life) {
                UIManager.put("OptionPane.background", Color.BLACK);
                UIManager.put("Panel.background", Color.BLACK);
                UIManager.put("OptionPane.messageForeground", Color.RED);
                ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                JOptionPane.showMessageDialog(null, "As you press the button, you feel a shock flow thorugh your body.\nYou collapse on the floor and take your final breath to the smell of something burning", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                main(null);
                }
                
                else if(life) {
                        UIManager.put("OptionPane.background", Color.PINK);
                        UIManager.put("Panel.background", Color.PINK);
                        UIManager.put("OptionPane.messageForeground", Color.RED);
                        ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                        JOptionPane.showMessageDialog(null, "The card that the ogre gave you was an extra life card, spareing you just this once", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                        life=false;

                 UIManager.put("OptionPane.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("Panel.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("OptionPane.messageForeground", Color.YELLOW);
                        hole(fr2, life);
                }
                
        }

        private static void eastRoom(JFrame fr2, boolean battery, boolean lights) {
                String answer = JOptionPane.showInputDialog("You enter a room filled with broken circuts, theres a faint noise in the room\nYou see a slot where a battery could fit");
                System.out.println(battery);

                if (answer.equalsIgnoreCase("go West")|answer.equalsIgnoreCase("west")|answer.equalsIgnoreCase("w")){
                        door(fr2, battery, battery, lights);
                }
                
                else if (answer.equalsIgnoreCase("put battery in slot")|(answer.equalsIgnoreCase("use battery"))) {
                        
                        if(!battery) {
                                JOptionPane.showMessageDialog(fr2, "You don't have a battery!");
                                eastRoom(fr2, battery, lights); 
                        }
                        else if(battery=true) {
                                JOptionPane.showMessageDialog(fr2, "The battery turns on a series of lights allowing you to see better");
                                lights = true;
                                eastRoomSolved(fr2, lights, lights);
                        }
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        eastRoom(fr2, battery, lights);
                }
                
        }

        private static void eastRoomSolved(JFrame fr2, boolean battery, boolean lights) {
                String answer = JOptionPane.showInputDialog("You enter a room filled with broken circuts, theres a faint noise in the room");

                if (answer.equalsIgnoreCase("go West")|answer.equalsIgnoreCase("west")|answer.equalsIgnoreCase("w")){
                        door(fr2, lights, lights, lights);
                }
                
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        eastRoom(fr2, battery, lights);
                }
                
        }
                

        private static void northRoom(JFrame fr2, boolean battery) {
                String answer = JOptionPane.showInputDialog("You enter a large room, there's a few rocks in one of the corners that look liftable, and a small waterfall with a pond in another");
                if (answer.equalsIgnoreCase("move rocks")|answer.equalsIgnoreCase("take rocks")|answer.equalsIgnoreCase("lift rocks")) {
                        String answer1 = JOptionPane.showInputDialog("You found a battery under the rocks");
                        if (answer1.equalsIgnoreCase("take battery")) {
                                JOptionPane.showMessageDialog(fr2, "Battery Taken");
                                battery = true;
                                northRoom(fr2, battery);
                        }
                        else {
                                JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                                northRoom(fr2, battery);
                        }
                }
                else if (answer.equalsIgnoreCase("move rock")|answer.equalsIgnoreCase("take rock")|answer.equalsIgnoreCase("lift rock")) {
                    String answer2 = JOptionPane.showInputDialog("You enter a large room, there's a few rocks in one of the corners that look liftable, and a small waterfall with a pond in another","There are multiple rocks");
                    if (answer2.equalsIgnoreCase("move rocks")|answer2.equalsIgnoreCase("take rocks")|answer2.equalsIgnoreCase("lift rocks")) {
                            String answer3 = JOptionPane.showInputDialog("You found a battery under the rocks");
                            if (answer3.equalsIgnoreCase("take battery")) {
                                    JOptionPane.showMessageDialog(fr2, "Battery Taken");
                                    battery = true;
                                    northRoom(fr2, battery);
                            }
                            else {
                                    JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                                    northRoom(fr2, battery);
                            }
                    }
                }
                else if (answer.equalsIgnoreCase("swim in waterfall")|answer.equalsIgnoreCase("go in waterfall")|answer.equalsIgnoreCase("enter waterfall")) {
                        String answer1 = JOptionPane.showInputDialog("You take a quick swim in under the waterfall\nYou feel a loose grate at your feet");
                        do {
                        if (answer1.equalsIgnoreCase("lift grate")|answer1.equalsIgnoreCase("open grate")) {
                        		JOptionPane.showMessageDialog(fr2, "Warning\nThis section is still in beta");
                                grate(fr2);
                        }
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer1);
                        }while(!answer1.equalsIgnoreCase("lift grate")|(!answer1.equalsIgnoreCase("open grate")));
                }
                else if (answer.equalsIgnoreCase("go south")|answer.equalsIgnoreCase("south")|answer.equalsIgnoreCase("s")){
                        door(fr2, battery, battery, battery);
                }
                else {
                        JOptionPane.showMessageDialog(fr2, "You can't "+answer);
                        northRoom(fr2, battery);
        }
                
                
        }

        private static void grate(JFrame fr2) {
                String answer = JOptionPane.showInputDialog("You open the grate and see a underwater tunnel");
                if (answer.equalsIgnoreCase("enter tunnel")|answer.equalsIgnoreCase("Go in tunnel")) {
                        JOptionPane.showMessageDialog(fr2, "You jump into the tunnel and start swimming");
                        JOptionPane.showMessageDialog(fr2, "You swim as fast as you can looking for air");
                        JOptionPane.showMessageDialog(fr2, "Your eyes start to close");
                        String answer1 = JOptionPane.showInputDialog("Just as your accepting death, you see a hole in the roof");
                        if (answer1.equalsIgnoreCase("swim to hole")|answer1.equalsIgnoreCase("go to hole")) {
                                JOptionPane.showMessageDialog(fr2, "You reach the hole and gasp for air.\nYou pull yourself out of the hole");
                                northTunnel(fr2);
                        }
                }
                
                
        }

        private static void fail(JFrame fr2, boolean life) {
                if (!life) {
                UIManager.put("OptionPane.background", Color.BLACK);
                UIManager.put("Panel.background", Color.BLACK);
                UIManager.put("OptionPane.messageForeground", Color.RED);
                ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                JOptionPane.showMessageDialog(null, "FAIL\nYou hear a sound behind you, but before you can look, you feel a sharp pain in your neck and you collapse.", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                main(null);
                }
                else if(life) {
                        UIManager.put("OptionPane.background", Color.PINK);
                        UIManager.put("Panel.background", Color.PINK);
                        UIManager.put("OptionPane.messageForeground", Color.RED);
                        ImageIcon icon = new ImageIcon("res//heart_pixelart.png/");
                        JOptionPane.showMessageDialog(null, "The card that the ogre gave you was an extra life card, spareing you just this once", "You Died!", JOptionPane.INFORMATION_MESSAGE, icon);
                        life=false;

                 UIManager.put("OptionPane.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("Panel.background",new ColorUIResource(102, 0, 0));
                 UIManager.put("OptionPane.messageForeground", Color.YELLOW);
                        button(fr2, life);
                }
                
        }
}
